Looks Good To Me
================

Dear friend,

This is a Chrome extension to augment Github pull request pages for greater plus one visibility.

You can view a project's pull request index page to enjoy the effect.

Love,
Nikolai
